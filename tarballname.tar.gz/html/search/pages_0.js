var searchData=
[
  ['practice2',['practice2',['../md_README.html',1,'']]]
];
